package Gamer.Model;


import javafx.animation.PathTransition;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.shape.Line;
import javafx.util.Duration;

import java.util.*;

public class Sun {
    private ArrayList<star> suns = new ArrayList<star>();
    Group root = new Group();
    Random rand = new Random();
    int difficulty;
    ArrayList<Integer> positions = new ArrayList<Integer>(Arrays.asList(300,380,460,540,620,700));
    private Timer timer;


    public Sun(Group root){
        this.root=root;
        this.suns=suns;
        this.difficulty=6;
        suns = generateSuns(positions);


    }


    public ArrayList<star> generateSuns(ArrayList<Integer> positions){

        for (int i = 0; i < positions.size(); i++){
                System.out.println("ImageCalled");
                star str =  new star(positions.get(i), -10, root);
                startTimer(str);
                //updateAnimation(str);
                suns.add(str);
        }

        return suns;
    }

    public ArrayList<star> getSuns(){
        return suns;
    }

    private void startTimer(star str) {
        this.timer = new Timer();
        TimerTask timerTask = new TimerTask() {
            public void run() {
                Platform.runLater(new Runnable() {
                    public void run() {
                        updateAnimation(str);
                    }
                });
            }
        };

        long frameTimeInMilliseconds = (long)(4000);
        this.timer.schedule(timerTask, 0, frameTimeInMilliseconds);
    }

    public void updateAnimation(star str){
        Line line8 = new Line();
        line8.setStartX(400.0);
        line8.setStartY(0.0);
        line8.setEndX(400.0);
        line8.setEndY(300.0);

        PathTransition transition13 = new PathTransition();
        transition13.setNode(str.s);
        transition13.setDuration(Duration.seconds(5));
        transition13.setPath(line8);
        transition13.setDelay(Duration.seconds(0));
        transition13.play();

    }



}
