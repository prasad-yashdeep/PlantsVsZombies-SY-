package Gamer.Model;

import javafx.animation.PathTransition;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Line;
import javafx.util.Duration;

public class star {

    private int row;
    private int column;
    public StackPane s = new StackPane();
    private Group root = new Group();
    private Image star;
    private ImageView starView;


    private double speed;

    public star(int row, int column,Group root){
        this.row=row;
        this.column=column;
        this.star = new Image("file:src/Gamer/res/sun2.png");
        this.starView= new ImageView(star);
        starView.setFitHeight(100);
        starView.setFitWidth(100);
        s.getChildren().add(starView);
        s.setPrefHeight(20);
        s.setPrefHeight(20);
        root.getChildren().add(s);
        s.setTranslateY(-10);
        s.setTranslateX(row);

        this.speed = 0.1;
    }
    public void removeImage() {
        this.s.getChildren().remove(this.starView);
        this.root.getChildren().remove(this.s);
    }




    public int getRow() {
        return this.row;
    }

    public int getColumn(){ return this.column;}







    public void step() {
        Line line8 = new Line();
        line8.setStartX(0.0);
        line8.setStartY(0.0);
        line8.setEndX(75.0);
        line8.setEndY(0.0);

        PathTransition transition13 = new PathTransition();
        transition13.setNode(s);
        transition13.setDuration(Duration.seconds(5));
        transition13.setPath(line8);
        transition13.setDelay(Duration.seconds(15));
        transition13.play();


    }
}





