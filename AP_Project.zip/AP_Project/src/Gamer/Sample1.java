package Gamer;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Sample1 implements Initializable {


    ArrayList<String> Users_Password = new ArrayList<String>();


    @FXML
    private ImageView fb1;

    @FXML
    private ImageView fin1;

    @FXML
    private TextField text1;

    @FXML
    private TextField text2;

    @FXML
    private Button b1;

    @FXML
    private StackPane y1;

    @FXML
    private AnchorPane s1;




    @FXML
    private void loadThird(ActionEvent event) throws IOException {
        System.out.println("yo");
        Parent root = FXMLLoader.load(getClass().getResource("levels.fxml"));
        System.out.println("yo");
        Scene scene = b1.getScene();
        root.translateXProperty().set(scene.getWidth());
        y1.getChildren().add(root);
        Timeline timeline = new Timeline();
        KeyValue kv = new KeyValue(root.translateXProperty(),0, Interpolator.EASE_IN);
        KeyFrame kf = new KeyFrame(Duration.seconds(1), kv);
        timeline.getKeyFrames().add(kf);
        timeline.setOnFinished(event1 -> {
            System.out.println("yo");
            y1.getChildren().remove(s1);
        });
        if ((text1.getText() != null && text2.getText()!=null)) {
            System.out.println(text1.getText());
            System.out.println(text2.getText());
            Users_Password.add(text1.getText());
            Users_Password.add(text2.getText());
            System.out.println(Users_Password.get(0));
            System.out.println(Users_Password.get(1));
        } else {
            System.out.println("Enter a valid string");
        }
        timeline.play();

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}