/**
 *
 */
module AP.Project {

    requires javafx.controls;
    requires javafx.fxml;
    requires kotlin.stdlib;
    requires javafx.web;
    requires javafx.media;

    opens Gamer;
}