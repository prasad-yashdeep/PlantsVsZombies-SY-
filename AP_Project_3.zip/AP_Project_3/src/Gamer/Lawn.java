package Gamer;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import Gamer.Model.*;
import Gamer.controller.*;

public class Lawn extends Application implements Initializable {

    private int difficulty;
    Stage window;
    Scene scene3;
    Group root2 = new Group();


    public Lawn(){
        this.difficulty=2;
    }

    @FXML
    private StackPane s1;

    @FXML
    private StackPane s2;

    @FXML
    private StackPane s3;

    @FXML
    private StackPane s4;

    @FXML
    private StackPane s5;

    @FXML
    public ImageView img1;
    @FXML
    public ImageView img2;
    @FXML
    public ImageView img3;
    @FXML
    public ImageView img4;
    @FXML
    public ImageView img5;
    @FXML

    public ImageView img6;
    @FXML


    public ImageView img7;
    @FXML

    public ImageView img8;
    @FXML


    public ImageView img9;
    @FXML


    public ImageView img10;
    @FXML

    public ImageView img11;

    @FXML

    public ImageView iimg12;

    @FXML
    private Image sunflower;

    @FXML
    private Image wallnut;

    @FXML
    private Image mine1;

    @FXML
    private Image cherry;

    @FXML
    private Image peashooter1;

    @FXML
    private Label sun2;


    public static void main(String[] args) {
        launch(args);
    }
    AnchorPane root;
    @Override
    public void start(Stage primaryStage) throws IOException {
        window = primaryStage;
        root = FXMLLoader.load(getClass().getResource("/Gamer/lawn.fxml"));
        scene3=new Scene(root, 700, 400);
        window.setScene(scene3);
        primaryStage.show();
        root2.getChildren().add(root);

        Enemy enemy = new Enemy(root2, 2);
        Player player = new Player(root2,sun2);
        // set detection
        s1.setOnDragDetected(new PlantDragController(s1, cherry));
        s2.setOnDragDetected(new PlantDragController(s2, cherry));
        s3.setOnDragDetected(new PlantDragController(s3, mine1));
        s4.setOnDragDetected(new PlantDragController(s4, wallnut));
        s5.setOnDragDetected(new PlantDragController(s5, sunflower));

        scene3.setOnDragOver(new PlantDragOverController());
        scene3.setOnDragDropped(new PlantDragDropController( root2, player));
        scene3.setOnMouseClicked(new SunController(player,root2,sun2));
        //initiateStage = primaryStage;
        GameController controller = new GameController(1,player,enemy,primaryStage);
        controller.initialize();

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }


    @FXML
    private ProgressBar ipb1;


    static double ii = 0;
    //EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {
    public void handle(ActionEvent e)
    {
        // set progress to different level of progressbar
        ii += 0.1;
        ipb1.setProgress(ii);

    }

    public Stage getInitiateStage() {
        return window;
    }



}

class PlantDragController implements EventHandler<MouseEvent> {
    private StackPane stackPane;
    private Image image;

    public PlantDragController(StackPane stackPane, Image image) {
        this.stackPane = stackPane;
        this.image = image;
    }
    @Override
    public void handle(MouseEvent event) {
        Dragboard drag = this.stackPane.startDragAndDrop(TransferMode.MOVE);
        ClipboardContent content = new ClipboardContent();
        String id = this.stackPane.getId();
        content.putImage(this.image);
        if (id == "peashooter") {
            content.putString("peashooter");
        } else if (id == "sunflower"){
            content.putString("sunflower");
        } else if (id == "wallnut"){
            content.putString("wallnut");
        } else if (id == "potatoMine"){
            content.putString("potatoMine");
        }
        drag.setContent(content);
    }

}








