package Gamer;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Levels  implements Initializable {
    @FXML
    private Button btn1;

    @FXML
    private Button back;

    @FXML
    private Button btn2;

    @FXML
    private Button btn3;

    @FXML
    private Button btn4;

    @FXML
    private AnchorPane s1;

    @FXML
    private Button btn5;

    @FXML
    private AnchorPane anch1;

    @FXML
    private StackPane y1;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btn1.setOnAction(event -> {
            MainGame game = new MainGame(1);
            try{

                game.start(game.getInitiateStage());
            } catch (Exception e){
                e.printStackTrace();
                System.err.println("Can not initiate game");
            }

        });
        btn2.setOnAction(event -> {
            MainGame game = new MainGame(2);
            try{

                game.start(game.getInitiateStage());
            } catch (Exception e){
                e.printStackTrace();
                System.err.println("Can not initiate game");
            }

        });
        btn3.setOnAction(event -> {
            MainGame game = new MainGame(3);
            try{

                game.start(game.getInitiateStage());
            } catch (Exception e){
                e.printStackTrace();
                System.err.println("Can not initiate game");
            }

        });
        btn4.setOnAction(event -> {
            MainGame game = new MainGame(4);
            try{

                game.start(game.getInitiateStage());
            } catch (Exception e){
                e.printStackTrace();
                System.err.println("Can not initiate game");
            }

        });
        btn5.setOnAction(event -> {
            MainGame game = new MainGame(5);
            try{

                game.start(game.getInitiateStage());
            } catch (Exception e){
                e.printStackTrace();
                System.err.println("Can not initiate game");
            }

        });
        back.setOnAction(event -> {
            System.out.println("yo");
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("sample.fxml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("yo");
            Scene scene = back.getScene();
            root.translateXProperty().set(scene.getWidth());
            y1.getChildren().add(root);
            Timeline timeline = new Timeline();
            KeyValue kv = new KeyValue(root.translateXProperty(),0, Interpolator.EASE_IN);
            KeyFrame kf = new KeyFrame(Duration.seconds(1), kv);
            timeline.getKeyFrames().add(kf);
            timeline.setOnFinished(event1 -> {
                System.out.println("yo");
                y1.getChildren().remove(anch1);
            });
            timeline.play();
        });

    }




}
