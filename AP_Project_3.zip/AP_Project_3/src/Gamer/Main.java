package Gamer;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ProgressBar;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

import java.io.File;

public class Main extends Application {
    Stage window;
    Scene scene1,scene2,scene3,scene4;
    ProgressBar p1;

    @Override
    public void start(Stage primaryStage) throws Exception{


        window = primaryStage;
        Parent root = FXMLLoader.load(getClass().getResource("/Gamer/sample.fxml"));
        Parent root1 = FXMLLoader.load(getClass().getResource("/Gamer/sample1.fxml"));
        Parent root2 = FXMLLoader.load(getClass().getResource("/Gamer/lawn.fxml"));
        Parent root3 = FXMLLoader.load(getClass().getResource("/Gamer/levels.fxml"));
        window.setTitle("Plants VS Zombies");
        scene1=new Scene(root, 600, 600);
        scene2=new Scene(root1, 600, 600);
        scene3=new Scene(root2, 600, 600);
        scene4=new Scene(root3,600, 600);


        window.setScene(scene1);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
