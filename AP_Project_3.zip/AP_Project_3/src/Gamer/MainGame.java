package Gamer;

import Gamer.Model.*;
import Gamer.controller.*;
//import Gamer.func.PlantDragController;
import javafx.animation.PathTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.*;

import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import java.io.File;
import java.net.MalformedURLException;

public class MainGame extends Application {
    private Group root;
    public Button b1 = new Button("Option");
    private int difficulty;
    Stage initiateStage = new Stage();

    MainGame(int difficulty1)
    {
        difficulty=difficulty1;
    }


    public static void main(String[] args) {
        launch(args);
    }
    public void getChoice(ChoiceBox<String> choicebox)
    {
        String choice = choicebox.getValue();
        System.out.println(choice);
        if(choice=="Exit")
        {

            Stage stage = (Stage) b1.getScene().getWindow();
            stage.close();
        }
    }


    @Override
    public void start(Stage primaryStage) throws MalformedURLException {
        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);
            }
        });
        primaryStage.setTitle( "Plants VS Zombies" );
        this.root = new Group();
        Scene theScene = new Scene(root,1400,800);
        File file = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/img1.jpeg");
        String localUrl = file.toURI().toURL().toString();
        Image background = new Image(localUrl);
        ImageView backgroundView = new ImageView();
        backgroundView.setImage(background);
        backgroundView.setFitWidth(1400.0);
        backgroundView.setFitHeight(800.0);
        //backgroundView.setPreserveRatio(true);
        root.getChildren().add(backgroundView);

        StackPane s12=new StackPane();
        File file12 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/1.png");
        String localUrl12 = file12.toURI().toURL().toString();
        Image lawnmower1 = new Image(localUrl12);
        ImageView imageView1 = new  ImageView(lawnmower1);
        s12.getChildren().add(imageView1);
        s12.setTranslateX(160.0);
        s12.setTranslateY(70.0);
        s12.setPrefHeight(0.0);
        s12.setPrefWidth(0.0);
        root.getChildren().add(s12);


        StackPane s13=new StackPane();
        File file13 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/1.png");
        String localUrl13 = file12.toURI().toURL().toString();
        Image lawnmower2 = new Image(localUrl13);
        ImageView imageView2 = new  ImageView(lawnmower2);
        s13.getChildren().add(imageView2);
        s13.setTranslateX(160.0);
        s13.setTranslateY(200.0);
        s13.setPrefHeight(0.0);
        s13.setPrefWidth(0.0);
        root.getChildren().add(s13);

        StackPane s14=new StackPane();
        File file14 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/1.png");
        String localUrl14 = file14.toURI().toURL().toString();
        Image lawnmower3 = new Image(localUrl12);
        ImageView imageView3 = new  ImageView(lawnmower3);
        s14.getChildren().add(imageView3);
        s14.setTranslateX(160.0);
        s14.setTranslateY(330.0);
        s14.setPrefHeight(0.0);
        s14.setPrefWidth(0.0);
        root.getChildren().add(s14);

        StackPane s15=new StackPane();
        File file15 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/1.png");
        String localUrl15 = file12.toURI().toURL().toString();
        Image lawnmower4 = new Image(localUrl15);
        ImageView imageView4 = new  ImageView(lawnmower4);
        s15.getChildren().add(imageView4);
        s15.setTranslateX(160.0);
        s15.setTranslateY(460.0);
        s15.setPrefHeight(0.0);
        s15.setPrefWidth(0.0);
        root.getChildren().add(s15);

        StackPane s16=new StackPane();
        File file16 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/1.png");
        String localUrl16 = file12.toURI().toURL().toString();
        Image lawnmower5 = new Image(localUrl16);
        ImageView imageView5 = new  ImageView(lawnmower5);
        s16.getChildren().add(imageView5);
        s16.setTranslateX(160.0);
        s16.setTranslateY(600.0);
        s16.setPrefHeight(0.0);
        s16.setPrefWidth(0.0);
        root.getChildren().add(s16);

        StackPane s17=new StackPane();
        File file17 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/timer.jpeg");
        String localUrl17 = file17.toURI().toURL().toString();
        Image timer = new Image(localUrl17);
        ImageView timer1 = new  ImageView(timer);
        timer1.setFitWidth(70);
        timer1.setFitHeight(70);
        s17.getChildren().add(timer1);
        s17.setTranslateX(750.0);
        s17.setTranslateY(30.0);
        s17.setPrefHeight(0.0);
        s17.setPrefWidth(0.0);
        root.getChildren().add(s17);

        //not visible
        StackPane timer_length=new StackPane();
        Label bar1 = new Label("");
        bar1.setBackground(new Background(new BackgroundFill(Color.AQUA, CornerRadii.EMPTY, Insets.EMPTY)));
        bar1.setTranslateX(1000);
        bar1.setTranslateY(65);
        timer_length.getChildren().add(bar1);
        root.getChildren().add(timer_length);




        Line line8 = new Line();
        line8.setStartX(0.0);
        line8.setStartY(0.0);
        line8.setEndX(200.0);
        line8.setEndY(0.0);

        PathTransition transition13 = new PathTransition();
        transition13.setNode(timer1);
        transition13.setDuration(Duration.seconds(10));
        transition13.setPath(line8);
        transition13.setDelay(Duration.seconds(0));
        transition13.play();
        StackPane layout= new StackPane();
        StackPane option = new StackPane();
        b1.setMinHeight(30);
        b1.setMinWidth(50);
        option.setTranslateX(1280.0);
        option.setTranslateY(30.0);
        option.setPrefHeight(30.0);
        option.setPrefWidth(70.0);
        layout.setTranslateX(1100.0);
        layout.setTranslateY(30.0);
        layout.setPrefHeight(30.0);
        layout.setPrefWidth(110.0);
        ChoiceBox<String> choicebox = new ChoiceBox<>();
        choicebox.getItems().add("Save Game");
        choicebox.getItems().add("Exit");
        choicebox.setValue("Save Game");
        option.getChildren().add(b1);
        layout.getChildren().add(choicebox);
        root.getChildren().add(layout);
        root.getChildren().add(option);
        b1.setOnAction(e-> getChoice(choicebox));

        if(difficulty==1){
            //adding peashooter
            StackPane s1 = new StackPane();
            File file1 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/Cartas_de_Plantas.png");
            String localUrl1 = file1.toURI().toURL().toString();
            Image peashooter = new Image(localUrl1);
            ImageView peashooter1 = new  ImageView(peashooter);
            s1.getChildren().add(peashooter1);
            s1.setTranslateX(300.0);
            s1.setTranslateY(1.0);
            s1.setPrefHeight(90.0);s1.setPrefWidth(90.0);

            Label sun1 = new Label(Integer.toString(200));
            sun1.setFont(Font.font("Verdana", FontWeight.BOLD,25));
            this.root.getChildren().add(sun1);
            sun1.setTranslateX(210);
            sun1.setTranslateY(65);



            File file4 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/bar.png");
            String localUrl4 = file4.toURI().toURL().toString();
            Image down = new Image(localUrl4);
            ImageView barView = new ImageView();
            barView.setImage(down);
            barView.setTranslateX(175);
            barView.smoothProperty();
            barView.setFitWidth(500);
            barView.setFitHeight(100);

            StackPane bar = new StackPane();
            BorderPane sun = new BorderPane();
            root.getChildren().add(bar);
            bar.getChildren().add(sun);
            bar.getChildren().add(barView);
            root.getChildren().add(s1);
            s1.setId("peashooter");





            primaryStage.setScene( theScene );
            primaryStage.setResizable(false);
            primaryStage.show();

            Enemy enemy = new Enemy(root,difficulty);
            Player player = new Player(root,sun1);
            // set detection
            System.out.println("Yash");
            s1.setOnDragDetected(new PlantDragController(s1, peashooter));
            //s2.setOnDragDetected(new PlantDragController(s2, sunflower));
            //s3.setOnDragDetected(new PlantDragController(s3, wallnut));
            theScene.setOnDragOver(new PlantDragOverController());
            theScene.setOnDragDropped(new PlantDragDropController(root, player));
            theScene.setOnMouseClicked(new SunController(player,root,sun1));
            initiateStage = primaryStage;
            GameController controller = new GameController(difficulty,player,enemy,initiateStage);
            controller.initialize();

        }

        if(difficulty==2){
            StackPane s1 = new StackPane();
            File file1 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/Cartas_de_Plantas.png");
            String localUrl1 = file1.toURI().toURL().toString();
            Image peashooter = new Image(localUrl1);
            ImageView peashooter1 = new  ImageView(peashooter);
            s1.getChildren().add(peashooter1);
            s1.setTranslateX(300.0);
            s1.setTranslateY(1.0);
            s1.setPrefHeight(90.0);s1.setPrefWidth(90.0);

            Label sun1 = new Label(Integer.toString(200));
            sun1.setFont(Font.font("Verdana", FontWeight.BOLD,25));
            this.root.getChildren().add(sun1);
            sun1.setTranslateX(210);
            sun1.setTranslateY(65);




            StackPane s2 = new StackPane();
            File file2 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/sunflower.png");
            String localUrl2 = file2.toURI().toURL().toString();
            Image sunflower = new Image(localUrl2);
            ImageView sunflower1 = new  ImageView(sunflower);
            s2.getChildren().add(sunflower1);
            s2.setTranslateX(370.0);
            s2.setTranslateY(1.0);
            s2.setPrefHeight(90.0);
            s2.setPrefWidth(90.0);




            File file4 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/bar.png");
            String localUrl4 = file4.toURI().toURL().toString();
            Image down = new Image(localUrl4);
            ImageView barView = new ImageView();
            barView.setImage(down);
            barView.setTranslateX(175);
            barView.smoothProperty();
            barView.setFitWidth(500);
            barView.setFitHeight(100);

            StackPane bar = new StackPane();
            BorderPane sun = new BorderPane();
            root.getChildren().add(bar);
            bar.getChildren().add(sun);
            bar.getChildren().add(barView);
            root.getChildren().add(s1);
            root.getChildren().add(s2);

            s1.setId("peashooter");
            s2.setId("sunflower");





            primaryStage.setScene( theScene );
            primaryStage.setResizable(false);
            primaryStage.show();

            Enemy enemy = new Enemy(root,difficulty);
            Player player = new Player(root,sun1);
            // set detection
            System.out.println("Yash");
            s1.setOnDragDetected(new PlantDragController(s1, peashooter));
            s2.setOnDragDetected(new PlantDragController(s2, sunflower));
            //s3.setOnDragDetected(new PlantDragController(s3, wallnut));
            theScene.setOnDragOver(new PlantDragOverController());
            theScene.setOnDragDropped(new PlantDragDropController(root, player));
            theScene.setOnMouseClicked(new SunController(player,root,sun1));
            initiateStage = primaryStage;
            GameController controller = new GameController(difficulty,player,enemy,initiateStage);
            controller.initialize();



        }



        if(difficulty==3){
            //adding peashooter
            StackPane s1 = new StackPane();
            File file1 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/Cartas_de_Plantas.png");
            String localUrl1 = file1.toURI().toURL().toString();
            Image peashooter = new Image(localUrl1);
            ImageView peashooter1 = new  ImageView(peashooter);
            s1.getChildren().add(peashooter1);
            s1.setTranslateX(325.0);
            s1.setTranslateY(1.0);
            s1.setPrefHeight(90.0);s1.setPrefWidth(90.0);

            Label sun1 = new Label(Integer.toString(200));
            sun1.setFont(Font.font("Verdana", FontWeight.BOLD,25));
            this.root.getChildren().add(sun1);
            sun1.setTranslateX(210);
            sun1.setTranslateY(65);




            StackPane s2 = new StackPane();
            File file2 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/sunflower.png");
            String localUrl2 = file2.toURI().toURL().toString();
            Image sunflower = new Image(localUrl2);
            ImageView sunflower1 = new  ImageView(sunflower);
            s2.getChildren().add(sunflower1);
            s2.setTranslateX(425.0);
            s2.setTranslateY(1.0);
            s2.setPrefHeight(90.0);s1.setPrefWidth(90.0);




            StackPane s3 = new StackPane();
            File file3 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/wallnut.png");
            String localUrl3 = file3.toURI().toURL().toString();
            Image wallnut = new Image(localUrl3);
            ImageView wallnut1 = new  ImageView(wallnut);
            s3.getChildren().add(wallnut1);
            s3.setTranslateX(500.0);
            s3.setTranslateY(1.0);
            s3.setPrefHeight(90.0);s1.setPrefWidth(90.0);




            File file4 = new File("/Users/shreeyagarg/Desktop/AP_Project_3/src/Gamer/res/bar.png");
            String localUrl4 = file4.toURI().toURL().toString();
            Image down = new Image(localUrl4);
            ImageView barView = new ImageView();
            barView.setImage(down);
            barView.setTranslateX(175);
            barView.smoothProperty();
            barView.setFitWidth(500);
            barView.setFitHeight(100);



            StackPane bar = new StackPane();
            BorderPane sun = new BorderPane();
            root.getChildren().add(bar);
            bar.getChildren().add(sun);
            bar.getChildren().add(barView);
            root.getChildren().add(s1);
            root.getChildren().add(s2);
            root.getChildren().add(s3);
            s1.setId("peashooter");
            s2.setId("sunflower");
            s3.setId("wallnut");


            //root.getChildren().add(s1);

            primaryStage.setScene( theScene );
            primaryStage.setResizable(false);
            primaryStage.show();

            Enemy enemy = new Enemy(root,difficulty);
            Player player = new Player(root,sun1);

            Gamer.controller.PlantDragController pea1= new Gamer.controller.PlantDragController(s1, peashooter);
            s1.setOnDragDetected(pea1);
            Gamer.controller.PlantDragController pea2 =new Gamer.controller.PlantDragController(s2,sunflower);
            s2.setOnDragDetected(pea2);
            Gamer.controller.PlantDragController pea3 =new Gamer.controller.PlantDragController(s3,wallnut);
            s3.setOnDragDetected(pea3);
            theScene.setOnDragOver(new PlantDragOverController());
            theScene.setOnDragDropped(new PlantDragDropController(root, player));
            theScene.setOnMouseClicked(new SunController(player,root,sun1));
            initiateStage = primaryStage;
            GameController controller = new GameController(difficulty,player,enemy,initiateStage);
            controller.initialize();

        }
        primaryStage.show();


    }
    public Stage getInitiateStage() {
        return initiateStage;
    }

    }

