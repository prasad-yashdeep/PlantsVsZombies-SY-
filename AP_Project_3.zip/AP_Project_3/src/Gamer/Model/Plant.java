package Gamer.Model;
public interface Plant{


    public void setPosition(int x, int y);

    public int getHealth();
    public void setHealth(int health);
    public int getPower();
    public void setPower(int power);
    public int getPrice();
    public void step();
    public void removeImage();
    public int getRow();
    public int getColumn();
    public String getName();


}
